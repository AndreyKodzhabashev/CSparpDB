﻿namespace SoftJail.Data.Models.Enums
{
    public enum Weapon
    {
        Knife = 1,
        FlashPulse,
        ChainRifle,
        Pistol,
        Sniper
    }
}