﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-CVEQJBP\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}