﻿namespace VaporStore.Data.Models
{
    public enum PurchaseType
    {
        //with possible values(“Retail”, “Digital”) (required) 
        Retail = 1,
        Digital = 2
    }
}