﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-CVEQJBP\SQLEXPRESS;Database=Cinema;Trusted_Connection=True";
    }
}
