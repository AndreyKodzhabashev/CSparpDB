﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase
{
    class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-CVEQJBP\SQLEXPRESS;Database=HospitalDB;Trusted_Connection=True;";
    }
}
