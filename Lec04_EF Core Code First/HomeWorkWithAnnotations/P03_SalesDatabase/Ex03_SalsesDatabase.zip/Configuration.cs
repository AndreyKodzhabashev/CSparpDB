﻿namespace P03_SalesDatabase
{
    class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-CVEQJBP\SQLEXPRESS;Database=SalesDB;Trusted_Connection=True;";
    }
}
