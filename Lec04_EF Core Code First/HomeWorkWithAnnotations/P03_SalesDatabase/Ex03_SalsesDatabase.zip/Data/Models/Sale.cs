﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace P03_SalesDatabase.Data.Models
{
    [Table("Sales")]
    public class Sale
    {
        [Key] [Column("SalesID")] public int SaleId { get; set; }

        [Required]
        public DateTime Date { get; set; }

        //navigation for Product
        public int ProductId { get; set; }
        [ForeignKey("ProductId")]
        [InverseProperty("Sales")]
        public Product Product { get; set; }

        //navigation for Customer
        public int CustomerId { get; set; }
        [ForeignKey("CustomerId")]
        [InverseProperty("Sales")]
        public Customer Customer { get; set; }

        //navigation for Store
        public int StoreId { get; set; }

        [ForeignKey("StoreId")]
        [InverseProperty("Sales")]
        public Store Store { get; set; }
    }
}