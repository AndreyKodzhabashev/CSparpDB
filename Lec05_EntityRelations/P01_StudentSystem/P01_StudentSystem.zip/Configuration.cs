﻿namespace P01_StudentSystem
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-CVEQJBP\SQLEXPRESS;Database=StudentSystemDB;Trusted_Connection=True;";
    }
}