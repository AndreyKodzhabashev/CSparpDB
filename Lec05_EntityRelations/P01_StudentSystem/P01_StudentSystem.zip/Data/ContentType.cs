﻿namespace P01_StudentSystem.Data
{
    public enum ContentType
    {
        Application = 1,
        Pdf,
        Zip
    }
}