﻿namespace P03_FootballBetting
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-CVEQJBP\SQLEXPRESS;Database=FootballBettingDB;Trusted_Connection=True;";
    }
}