﻿namespace P03_FootballBetting.Data.Models
{
    public enum PredictionType
    {//DONE
        HomeTeam = 1,
        Draw = 2,
        AwayTeam = 3
    }
}