﻿namespace BillsPaymentSystem.App.Core.Contracts
{
    using Data;

    public interface ICommandInterpreter
    {
        string ReadCommand(string[] inputParams, BillsPaymentSystemContext context);
    }
}