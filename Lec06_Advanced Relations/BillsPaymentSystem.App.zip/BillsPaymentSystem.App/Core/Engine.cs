﻿namespace BillsPaymentSystem.App.Core
{
    using System;
    using Contracts;
    using Data;

    public class Engine : IEngine
    {
        private readonly ICommandInterpreter interpreter;

        public Engine(ICommandInterpreter interpreter)
        {
            this.interpreter = interpreter;
        }

        public void Run()
        {
            while (true)
            {
                string[] inputParams = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);
                using (BillsPaymentSystemContext context = new BillsPaymentSystemContext())
                {
                    try
                    {
                        string result = interpreter.ReadCommand(inputParams, context);
                        Console.WriteLine(result);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                }
            }
        }
    }
}