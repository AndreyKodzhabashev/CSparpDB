﻿namespace BillsPaymentSystem.App
{
    using System;
    using BillsPaymentSystem.App.Core;
    using BillsPaymentSystem.App.Core.Contracts;
    using BillsPaymentSystem.Data;
    using Microsoft.EntityFrameworkCore;

    public class StartUp
    {
        public static void Main()
        {
            using (var context = new BillsPaymentSystemContext())
            {
               
                //context.Database.EnsureDeleted();
                //context.Database.EnsureCreated();
                //DbInitializer.Seed(context);
                ICommandInterpreter command = new CommandInterpreter();
                IEngine engine = new Engine(command);
                engine.Run();

                
            }
        }
    }
}