﻿namespace BillsPaymentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-CVEQJBP\SQLEXPRESS;Database=BillSystemDB;Trusted_Connection=True;";
    }
}