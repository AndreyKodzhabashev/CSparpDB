﻿namespace BillsPaymentSystem.Models.Enums
{
    public enum PaymentType
    {
        BankAccount = 1,
        CreditCard
    }
}