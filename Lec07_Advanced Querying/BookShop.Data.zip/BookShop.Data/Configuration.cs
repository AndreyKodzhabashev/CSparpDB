﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal const string ConnectionString =
            @"Server=DESKTOP-CVEQJBP\SQLEXPRESS;Database=BookShopDB;Trusted_Connection=True;";
    }
}